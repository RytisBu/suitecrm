<?php
$module_name = 'qwe12_BitCoin';
$listViewDefs [$module_name] = 
array (
  'CODE' => 
  array (
    'type' => 'text',
    'studio' => 'visible',
    'label' => 'LBL_CODE',
    'sortable' => false,
    'width' => '10%',
    'default' => true,
  ),
  'SYMBOL' => 
  array (
    'type' => 'text',
    'studio' => 'visible',
    'label' => 'LBL_SYMBOL',
    'sortable' => false,
    'width' => '10%',
    'default' => true,
  ),
  'RATE' => 
  array (
    'type' => 'text',
    'studio' => 'visible',
    'label' => 'LBL_RATE',
    'sortable' => false,
    'width' => '10%',
    'default' => true,
  ),
  'SYMBOL_DESCRIPTION' => 
  array (
    'type' => 'text',
    'studio' => 'visible',
    'label' => 'LBL_SYMBOL_DESCRIPTION',
    'sortable' => false,
    'width' => '10%',
    'default' => true,
  ),
  'RATE_FLOAT' => 
  array (
    'type' => 'text',
    'studio' => 'visible',
    'label' => 'LBL_RATE_FLOAT',
    'sortable' => false,
    'width' => '10%',
    'default' => true,
  ),
);
;
?>
